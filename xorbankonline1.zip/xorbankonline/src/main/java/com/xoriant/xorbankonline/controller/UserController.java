package com.xoriant.xorbankonline.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.xoriant.xorbankonline.dao.impl.CustomerDaoImpl;
import com.xoriant.xorbankonline.enums.Role;
import com.xoriant.xorbankonline.model.User;

@Controller
public class UserController {
	String message = "Welcome to Spring MVC!";
	 
	@RequestMapping("/hello")
	public ModelAndView showMessage(@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller");
		ModelAndView mv = new ModelAndView("helloworld");
		mv.addObject("message", message);
		mv.addObject("name", name);
		return mv;
	}
	
	@RequestMapping("/userLoginVerification")
	public ModelAndView userLoginVerification(
			@RequestParam(value = "username")String username,
			@RequestParam(value = "password")String password,
			@RequestParam(value = "role")String role			
			) {
		System.out.println("use login Verification");
		System.out.println(username);
		System.out.println(password);
		System.out.println(role);
		CustomerDaoImpl c=new CustomerDaoImpl();
		List<User> users=c.getUsers();
		for(User user:users) {
			//System.out.print(user.getUserName());
			
			if(user.getRole()==Role.valueOf(role)) {
				if(user.getUserName().equals(username)) {
					if(user.getPassword().equals(password)) {
						System.out.println("Login Successfull");
						if("Manager".equals(role)) {
						ModelAndView mv=new ModelAndView("managerDashboard");
						return mv;
						}
						else {
							ModelAndView mv=new ModelAndView("customerDashboard");
							return mv;							
						}
					}
					else {
						System.out.println("Incorrect Password");
					}
				}
				else {
					System.out.println("Incorrect Username");
				}
			}
		}
		return new ModelAndView();
	}
	@RequestMapping({"/userLogin","/"})
	public ModelAndView redirectToUserLoginPage() {
//		System.out.println("New User Account Controller");
		return new ModelAndView("index");
	}
	
}
