package com.xoriant.xorbankonline.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;

import com.xoriant.xorbankonline.enums.Gender;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class PersonalInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int personId; 
	
	public String personName;
	@Enumerated(EnumType.STRING)
	public Gender gender; 
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Date DateOfBirth; 
	public Date getDateOfBirth() {
		return DateOfBirth;
	}
	public void setDateOfBirth(int Year,int month,int date) {
		DateOfBirth = new Date(Year,month,date);
	}
	public String emailId;
	public long mobileNo;
	@OneToOne(cascade = CascadeType.ALL,targetEntity = Address.class)
	public Address address;
	public PersonalInfo() {
		// TODO Auto-generated constructor stub
	}
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

}
