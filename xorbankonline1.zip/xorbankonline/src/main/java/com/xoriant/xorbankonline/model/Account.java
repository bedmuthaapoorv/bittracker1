package com.xoriant.xorbankonline.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.xoriant.xorbankonline.enums.AccountType;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int accountNumber;
	@Enumerated(EnumType.STRING)
	public AccountType accounttype;
	
	public AccountType getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(AccountType accounttype) {
		this.accounttype = accounttype;
	}

	public int balance;
	
	@OneToOne(cascade = CascadeType.ALL,targetEntity = Branch.class)
	public Branch branch;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "account",fetch = FetchType.LAZY)
	List<BankTransaction> transaction=new ArrayList<BankTransaction>();
	
	@ManyToOne(cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
	@JoinColumn(name="customerId")
	public Customer customer;
	
	public Branch getBranch() {
		return branch;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public List<BankTransaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<BankTransaction> transaction) {
		this.transaction = transaction;
	}

	public Account() {
	
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
	public void addTransaction(BankTransaction bt) {
		transaction.add(bt);
	}

}
