package com.xoriant.xorbankonline.aop;

public class LoggingAspect {

}
