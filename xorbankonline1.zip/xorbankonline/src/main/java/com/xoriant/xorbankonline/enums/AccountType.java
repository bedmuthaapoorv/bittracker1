package com.xoriant.xorbankonline.enums;

public enum AccountType {
Saving,Current
}
