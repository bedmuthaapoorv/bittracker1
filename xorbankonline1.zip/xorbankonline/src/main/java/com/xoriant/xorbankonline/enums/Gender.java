package com.xoriant.xorbankonline.enums;

public enum Gender {
Male,Female
}
