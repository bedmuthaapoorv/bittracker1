package com.xoriant.xorbankonline.enums;

public enum TransactionType {
WITHDRAW, DEPOSIT, TRANSFER
}
