package com.xoriant.xorbankonline.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.xoriant.xorbankonline.enums.TransactionType;

@Entity
public class BankTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int transactionId;
	
	public double transactionAmount;
	
	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "accountId")
	public Account account;
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Date transactionDate;
	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(int Year,int month,int date) {
		this.transactionDate = new Date(Year,month,date);
	}

	@Enumerated(EnumType.STRING)
	public TransactionType transactionType;
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public BankTransaction() {
		
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String toString() {
		return "transactionId : "+transactionId+" Amount :"+transactionAmount+" Account Number : "+account.getAccountNumber()
		+" Transaction Date : "+transactionDate.toString()+" Transaction Type : "+transactionType.name();
	}

}
