package com.xoriant.xorbankonline.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Branch {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	public long branchId;
	
	@OneToOne(targetEntity = Account.class)
	public Account account;
	public String branchName;
	public String ifscCode;
	public String micrCode;
	
	@OneToOne(targetEntity = Manager.class)
	public Manager manager;
	
	@OneToOne(cascade = CascadeType.ALL,targetEntity = Address.class)
	public Address address;
	
	public long getBranchId() {
		return branchId;
	}

	public void setBranchId(long branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getMicrCode() {
		return micrCode;
	}

	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}

	public Branch() {
		// TODO Auto-generated constructor stub
	}

}
