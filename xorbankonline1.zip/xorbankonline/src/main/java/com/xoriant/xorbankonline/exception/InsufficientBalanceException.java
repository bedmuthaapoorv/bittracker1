package com.xoriant.xorbankonline.exception;

public final class InsufficientBalanceException {

}
