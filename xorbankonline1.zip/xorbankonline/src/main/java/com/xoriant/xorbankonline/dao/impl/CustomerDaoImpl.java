package com.xoriant.xorbankonline.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.sql.ordering.antlr.Factory;

import com.xoriant.xorbankonline.dao.CustomerDao;
import com.xoriant.xorbankonline.enums.AccountType;
import com.xoriant.xorbankonline.enums.Gender;
import com.xoriant.xorbankonline.enums.Role;
import com.xoriant.xorbankonline.enums.TransactionType;
import com.xoriant.xorbankonline.model.Account;
import com.xoriant.xorbankonline.model.BankTransaction;
import com.xoriant.xorbankonline.model.CurrentAccount;
import com.xoriant.xorbankonline.model.Customer;
import com.xoriant.xorbankonline.model.Manager;
import com.xoriant.xorbankonline.model.SavingAccount;
import com.xoriant.xorbankonline.model.User;
//import com.xoriant.xorbankonline.model.Trial;

public class CustomerDaoImpl implements CustomerDao{
    public void insert(){
	StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
  
SessionFactory factory = meta.getSessionFactoryBuilder().build();  
Session session = factory.openSession();  
Transaction t = session.beginTransaction();  
/*
Trial e1=new Trial();
e1.setName("apoorv");
e1.setA(1);
session.save(e1);  
*/
User u=new User();
u.setUserName("Apoorv");
u.setPassword("Apoorv");
u.setSecurityAnswer("Apoorv");
u.setSecurityQuestion("Apoorv");
//session.save(u);
Manager m=new Manager();
m.setPersonName("man");
m.setEmailId("man");
m.setMobileNo(0);
List<User> users=new ArrayList<User>();
users.add(u);
m.setUsers(users);
users.get(0).setManager(m);
session.save(m);
t.commit();  
System.out.println("successfully saved");    
factory.close();  
session.close();
    }
    
    public ArrayList getSession() {
    	
    	StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
        SessionFactory factory = meta.getSessionFactoryBuilder().build();  
        Session session = factory.openSession();  
        Transaction t = session.beginTransaction(); 
    	ArrayList SandTandF=new ArrayList();
    	SandTandF.add(session);
    	SandTandF.add(t);
    	SandTandF.add(factory);
        return SandTandF;
    }
    public List<User> getUsers() {
    	CustomerDaoImpl c=new CustomerDaoImpl();
    	Session session=(Session)c.getSession().get(0);
    	Transaction t=(Transaction)c.getSession().get(1);
    	SessionFactory f=(SessionFactory)c.getSession().get(2);
    	Query query=session.createQuery("from User");
    	List<User> results=query.getResultList();
    	/*for(User u:results) {
    		System.out.print(u.userName);		
    	}*/
    	t.commit();
    	closeSession(session,t,f);
    	return results;
    }
    public List<Manager> getManagers() {
    	CustomerDaoImpl c=new CustomerDaoImpl();
    	Session session=(Session)c.getSession().get(0);
    	Transaction t=(Transaction)c.getSession().get(1);
    	SessionFactory f=(SessionFactory)c.getSession().get(2);
    	Query query=session.createQuery("from Manager");
    	List<Manager> results=query.getResultList();
    	t.commit();
    	closeSession(session,t,f);
    	return results;
    }
    public List<Customer> getCustomers() {
    	CustomerDaoImpl c=new CustomerDaoImpl();
    	Session session=(Session)c.getSession().get(0);
    	Transaction t=(Transaction)c.getSession().get(1);
    	SessionFactory f=(SessionFactory)c.getSession().get(2);
    	Query query=session.createQuery("from Customer");
    	List<Customer> results=query.getResultList();
    	t.commit();
    	closeSession(session,t,f);
    	return results;
    }
    private void closeSession(Session session, Transaction t,SessionFactory factory) {
        factory.close();  
        session.close();
	}

	public static void main(String args[]) {
    	CustomerDaoImpl c=new CustomerDaoImpl();
    	StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
        SessionFactory factory = meta.getSessionFactoryBuilder().build();  
        Session session = factory.openSession();  
        Transaction t = session.beginTransaction();  
        /*
        Account a=new Account();
        a.setBalance(100);
        List<BankTransaction> bt=new ArrayList<BankTransaction>();
        BankTransaction bt1=new BankTransaction();
        bt1.setAccount(a);
        bt1.setTransactionAmount(10);
        bt1.setTransactionDate(2021, 12, 2);
        bt1.setTransactionType(TransactionType.DEPOSIT);
        a.setTransaction(bt);
        session.persist(a);
        t.commit();
        */
      /*  Manager m=new Manager();
        m.setEmailId("email");
        m.setMobileNo(0);
        m.setPersonName("manager1");
        List<User> a=new ArrayList<User>();
        User u=new User();
        u.setUserName("apoorv1");
        u.setPassword("apoorv1");
        u.setSecurityQuestion("answer the question");
        u.setSecurityAnswer("the answer");
        u.setManager(m);
        u.setRole(Role.Manager);
        a.add(u);
        m.setUsers(a);
        session.persist(m);
        */
        /*Customer c1=new Customer();
        Account a=new Account();
        a.setBalance(100);
        a.setCustomer(c1);
        List<Account> la=new ArrayList<Account>();
        la.add(a);
        c1.setAccount(la);
        
        session.persist(c1);
    */
        
        t.commit();  
        factory.close();  
        session.close();
        //c.addCustomer("apoorvbedmutha","12345","answer","question",1,"Apoorv","9561295237",Gender.Male,"email",1999,12,2);
        //c.addNewAccount();
        System.out.println("successfully saved");    
       
    	//c.insert();
    
    }

	public void addCustomer(
			String username,
			String password,
			String secAnswer,
			String secQuestion,
			int ManagerId,
			String customerName,
			String mobileNo,
			Gender gender,
			String email,
			int year,
			int month,
			int date) {
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
	
		User u=new User();
        u.setPassword(password);
        u.setRole(Role.Customer);
        u.setSecurityAnswer(secAnswer);
        u.setSecurityQuestion(secQuestion);
        u.setUserName(username);
        
        Manager m;
        int mflag=0;
        List<Manager> managers=c.getManagers();
        for(Manager man:managers) {
        	if(man.getPersonId()==ManagerId) {
        		m=man;
        		u.setManager(m);
        		mflag=1;
        		break;
        	}
        }
        if(mflag==0) {
        	m=managers.get(0);
        	m.addUser(u);
        	u.setManager(m);
        	System.out.print("manager not found");	
        }
/*      List<User> users=new ArrayList<User>();
        users.add(u);
        m.setPersonName("super manager");
        m.setMobileNo(999);
        m.setGender(Gender.Male);
        m.setEmailId("fd");
        m.setDateOfBirth(2020, 02, 10);
        m.setUsers(users);
        u.setManager(m);
        */
        Customer c1=new Customer();
        c1.setPersonName(customerName);
        c1.setUser(u);
        c1.setMobileNo(Long.parseLong(mobileNo));
        c1.setGender(gender);
        c1.setEmailId(email);
        c1.setDateOfBirth(year,month,date);
        u.setCustomer(c1);
        session.persist(u);
		t.commit();
        session.close();
        f.close();
        
        
	}

	private Manager getManagerById(int i) {
		
		return null;
	}

	public void addNewAccount(int balance,int customerId,int minimumBal,AccountType accountType) {
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
		if(accountType==AccountType.Current) {
		CurrentAccount ca=new CurrentAccount();
		ca.setBalance(balance);
		List<Customer> customers =c.getCustomers();
		for(Customer temp:customers) {
			if(temp.getPersonId()==customerId) {
				ca.setCustomer(temp);
				temp.addAccount(ca);
				break;
			}
		}
		ca.setMinimumBalance(minimumBal);
		session.persist(ca);
		}
		else {
			SavingAccount ca=new SavingAccount();
			ca.setBalance(balance);
			List<Customer> customers =c.getCustomers();
			for(Customer temp:customers) {
				if(temp.getPersonId()==customerId) {
					ca.setCustomer(temp);
					temp.addAccount(ca);
					break;
				}
			}
			ca.setMinimumBalance(minimumBal);
			session.persist(ca);
			
		}
		t.commit();
		c.closeSession(session, t, f);
	}

	public List<Account> getAccounts() {
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
		Query query=session.createQuery("from Account");
		List<Account> accounts=query.getResultList();
		t.commit();
		session.close();
		f.close();
		return accounts;
	}

	public void withdraw(int senderAccountNo,int amount) {
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
		Query query=session.createQuery("from Account A where A.accountNumber="+senderAccountNo);
		List<Account> accounts=query.getResultList();
		for(Account account:accounts) {
			int balance=account.getBalance();
			balance=balance-amount;
			account.setBalance(balance);
			BankTransaction bt=new BankTransaction();
			bt.setAccount(account);
			bt.setTransactionAmount(amount);
			bt.setTransactionDate(new Date());
			bt.setTransactionType(TransactionType.WITHDRAW);
			account.addTransaction(bt);
			session.save(account);
		}
		t.commit();
		session.close();
		f.close();
		
	}
	public void deposit(int recieverAccountNo,int amount) {
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
		Query query=session.createQuery("from Account A where A.accountNumber="+recieverAccountNo);
		List<Account> accounts=query.getResultList();
		for(Account account:accounts) {
			int balance=account.getBalance();
			balance=balance+amount;
			account.setBalance(balance);
			BankTransaction bt=new BankTransaction();
			bt.setAccount(account);
			bt.setTransactionAmount(amount);
			bt.setTransactionDate(new Date());
			bt.setTransactionType(TransactionType.DEPOSIT);
			account.addTransaction(bt);
			session.save(account);
		}
		t.commit();
		session.close();
		f.close();
		
	}

	public List<BankTransaction> getTransactions(int accountNo) {
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
		Query query=session.createQuery("from Account A where A.accountNumber="+accountNo);
		List<Account> accounts=query.getResultList();
		List<BankTransaction> transactions=new ArrayList<BankTransaction>();
//		List<String> miniStatement=new ArrayList<String>();
		for(Account account:accounts) {
			transactions=account.getTransaction();
		}

		return transactions;
	}

	public void changePassword(String oldpass, String newpass) {
		// TODO Auto-generated method stub
		CustomerDaoImpl c=new CustomerDaoImpl();
		ArrayList STF=c.getSession();
		Session session=(Session)STF.get(0);
		Transaction t=(Transaction)STF.get(1);
		SessionFactory f=(SessionFactory)STF.get(2);
		Query query=session.createQuery("from User");
		
	}
}
