package com.xoriant.xorbankonline.dao;

public interface CustomerDao {

}
