package com.xoriant.xorbankonline.controller;

public class ManagerController {

}
