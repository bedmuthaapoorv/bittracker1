package com.xoriant.xorbankonline.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.PrimaryKeyJoinColumn;

import com.xoriant.xorbankonline.enums.AccountType;

@Entity
@PrimaryKeyJoinColumn(name = "accountId")
public class SavingAccount extends Account{

	
	public double interestDate;
	public double minimumBalance;
	public int transactionsLimit;
	public double transactionsAmountLimit;
	public double getInterestDate() {
		return interestDate;
	}
	public void setInterestDate(double interestDate) {
		this.interestDate = interestDate;
	}
	public double getMinimumBalance() {
		return minimumBalance;
	}
	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}
	public int getTransactionsLimit() {
		return transactionsLimit;
	}
	public void setTransactionsLimit(int transactionsLimit) {
		this.transactionsLimit = transactionsLimit;
	}
	public double getTransactionsAmountLimit() {
		return transactionsAmountLimit;
	}
	public void setTransactionsAmountLimit(double transactionsAmountLimit) {
		this.transactionsAmountLimit = transactionsAmountLimit;
	}
	public SavingAccount() {
		this.setAccounttype(AccountType.Saving);
		// TODO Auto-generated constructor stub
	}

}
