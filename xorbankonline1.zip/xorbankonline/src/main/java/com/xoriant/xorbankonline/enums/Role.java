package com.xoriant.xorbankonline.enums;

public enum Role {
Manager,Customer
}
