package com.xoriant.xorbankonline.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.xoriant.xorbankonline.dao.impl.CustomerDaoImpl;
import com.xoriant.xorbankonline.enums.Gender;
import com.xoriant.xorbankonline.model.Account;
import com.xoriant.xorbankonline.model.BankTransaction;

import jdk.javadoc.internal.doclets.formats.html.markup.HtmlAttr.Role;
import com.xoriant.xorbankonline.enums.AccountType;
//@RequestMapping("/customer")
@Controller
public class CustomerController {

	@RequestMapping("addCustomer")
	public ModelAndView addCustomer() {
		ModelAndView mv=new ModelAndView("addCustomer");
		return mv;
	}
	@RequestMapping("newCustomer")
	public ModelAndView newCustomer(
			@RequestParam(value="username")String username,
			@RequestParam(value="password")String password,
			@RequestParam(value="secQuestion")String secQuestion,
			@RequestParam(value="secAnswer")String secAnswer,
			@RequestParam(value="managerId")int managerId,
			@RequestParam(value="customerName")String customerName,
			@RequestParam(value="mobileNo")String mobileNo,
			@RequestParam(value="gender")String gender,
			@RequestParam(value="email")String email,
			@RequestParam(value="date")String date
			) {
		int day=Integer.parseInt(date.split("/")[0]);
		int month=Integer.parseInt(date.split("/")[1]);
		int year=Integer.parseInt(date.split("/")[2]);
		CustomerDaoImpl c=new CustomerDaoImpl();
		c.addCustomer(username, password, secAnswer, secQuestion, managerId, customerName, mobileNo, Gender.valueOf(gender), email, year, month, day);
		ModelAndView mv=new ModelAndView("managerDashboard");
		mv.addObject("recentAction", "new customer "+customerName+" added successfully");
		return mv;
	}
	@RequestMapping("newAccount")
	public ModelAndView newAccount() {
		ModelAndView mv=new ModelAndView("newAccount");
		return mv;
	}
	@RequestMapping("addAccount")
	public ModelAndView addAccount(
			@RequestParam(value="balance")int balance,
			@RequestParam(value="customerId")int customerId,
			@RequestParam(value="minimumBalance")int minimumBalance,
			@RequestParam(value="accountType")String accountType
			) {
		ModelAndView mv=new ModelAndView("managerDashboard");
		CustomerDaoImpl c=new CustomerDaoImpl();
		c.addNewAccount(balance, customerId, minimumBalance, AccountType.valueOf(accountType));
		mv.addObject("recentAction", "New account Created for Customer "+customerId);
		return mv;
	}
	@RequestMapping("getBalance")
	public ModelAndView getbalance(
			@RequestParam(value="accountNo")int accountNo) {
		ModelAndView mv=new ModelAndView("managerDashboard");
		CustomerDaoImpl c=new CustomerDaoImpl();
		List<Account> accounts=c.getAccounts();
		for(Account account:accounts) {
			if(account.getAccountNumber()==accountNo) {
				mv.addObject("recentAction", "Account no :"+accountNo+" has balance "+account.getBalance()+" rupees");
				return mv; 
			}
		}
		mv.addObject("recentAction", "Account no invalid");
		return mv;
		}
	@RequestMapping("balanceEnquiry")
	public ModelAndView balanceEnquiry() 
	{
		return new ModelAndView("balanceEnquiry");
		
	}
	@RequestMapping("fundTransfer")
	public ModelAndView fundTransfer() 
	{
		return new ModelAndView("fundTransfer");
		
	}
	@RequestMapping("attemptTransfer")
	public ModelAndView attemptTransfer(
			@RequestParam(value="senderAccountNo") int senderAccountNo,
			@RequestParam(value="recieverAccountNo") int recieverAccountNo
			,@RequestParam(value="amount") int amount
			) 
	{	ModelAndView m=new ModelAndView("managerDashboard");
		CustomerDaoImpl c=new CustomerDaoImpl();
		c.withdraw(senderAccountNo,amount);
		c.deposit(recieverAccountNo,amount);
		m.addObject("recentAction","rs "+amount+" successfully transfered");
		return m;
		
	}
	@RequestMapping("miniStatementRequest")
	public ModelAndView miniStatementRequest() 
	{	ModelAndView m=new ModelAndView("miniStatement");		
		return m;
	}
	@RequestMapping("changePassword")
	public ModelAndView changePassword(){
		ModelAndView m=new ModelAndView("changePassword");
		return m;
	}
	@RequestMapping("changePasswordRequest")
	public ModelAndView changePasswordRequest(
			@RequestParam(value="oldPassword") String oldpass,
			@RequestParam(value="newPassword") String newpass
			){
		ModelAndView m=new ModelAndView("managerDashboard");
		CustomerDaoImpl c=new CustomerDaoImpl();
		c.changePassword(oldpass,newpass);
		m.addObject("recentAction", "Password changed successfully");
		return m;
	}
	@RequestMapping("miniStatementCalculation")
	public ModelAndView miniStatement(
			@RequestParam(value="accountNo") int accountNo
			) 
	{	ModelAndView m=new ModelAndView("managerDashboard");		
		CustomerDaoImpl c=new CustomerDaoImpl(); 
		List<BankTransaction> btList=c.getTransactions(accountNo);
		ArrayList<String> list=new ArrayList<String>();
		for(BankTransaction bt:btList) {
			list.add(bt.toString());
		}
		m.addObject("miniStatement", list);
		m.addObject("recentAction","Requested Mini Statement");
		return m;
	}
}
