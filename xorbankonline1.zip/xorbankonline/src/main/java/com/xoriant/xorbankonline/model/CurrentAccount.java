package com.xoriant.xorbankonline.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.PrimaryKeyJoinColumn;

import com.xoriant.xorbankonline.enums.AccountType;

@Entity
@PrimaryKeyJoinColumn(name="accountId")
public class CurrentAccount extends Account{
	
	public int transactionsLimit;
	public double minimumBalance;
	public double transactionLimit;
	
	public int getTransactionsLimit() {
		return transactionsLimit;
	}
	public void setTransactionsLimit(int transactionsLimit) {
		this.transactionsLimit = transactionsLimit;
	}
	public double getMinimumBalance() {
		return minimumBalance;
	}
	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}
	public double getTransactionLimit() {
		return transactionLimit;
	}
	public void setTransactionLimit(double transactionLimit) {
		this.transactionLimit = transactionLimit;
	}
	public CurrentAccount() {
		this.setAccounttype(AccountType.Current);
		// TODO Auto-generated constructor stub
	}

}
