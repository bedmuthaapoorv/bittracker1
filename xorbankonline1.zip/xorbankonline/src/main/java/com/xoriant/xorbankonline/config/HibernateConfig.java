package com.xoriant.xorbankonline.config;

public class HibernateConfig {

}
