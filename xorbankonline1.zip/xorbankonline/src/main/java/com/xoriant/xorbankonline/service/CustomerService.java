package com.xoriant.xorbankonline.service;

public interface CustomerService {

}
