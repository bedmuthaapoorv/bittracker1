package com.xoriant;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoggingController {
	
	public LoggingController() {
		// TODO Auto-generated constructor stub
	}
	private static final Logger LOGGER = LogManager.getLogger(Parent1Application.class);
	
	@GetMapping("/vul")
	public String test(@RequestParam("userInput") String userInput) {
		LOGGER.info("yp "+userInput);
		return "{}";
	}
}
