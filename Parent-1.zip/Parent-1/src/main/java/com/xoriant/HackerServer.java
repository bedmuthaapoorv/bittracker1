package com.xoriant;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HackerServer {

	public HackerServer() {
		// TODO Auto-generated constructor stub
	}
	@GetMapping("/data")
	public String incorrectData() {
		return "hacker's data";
	}
}
