package com.xoriant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Parent1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
